
<?php $__env->startSection('transaction', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="font-weight-bold">Transactions</h2>
    <div class="row mb-3">
        <div class="col-md-3 mb-3">
            <label for="product_id" class="form-label">Chose Product</label><br>
            <select class="product-select form-select" aria-label="Default select example" id="product_id">
                <option></option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" data-purchase_price="<?php echo e($product->purchase_price); ?>"
                        data-selling_price="<?php echo e($product->selling_price); ?>">
                        <?php echo e($product->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-danger" id="product_id-error"></small>
        </div>
        <div class="col-md-3 mb-3">
            <label for="purchase_price" class="form-label">Purchase Price</label>
            <div class="input-group input-group-sm">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="purchase_prices">Rp.</span>
                </div>
                <input disabled type="text" value="0" class="form-control text-end" id="purchase_price">
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <label for="selling_price" class="form-label">Selling Price</label>
            <div class="input-group input-group-sm">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="selling_prices">Rp.</span>
                </div>
                <input disabled type="text" value="0" class="form-control form-control-sm text-end"
                    id="selling_price">
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <label for="profit" class="form-label">Profit</label>
            <div class="input-group input-group-sm">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="profits">Rp.</span>
                </div>
                <input disabled type="text" value="0" class="form-control form-control-sm text-end" id="profit">
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <label for="customer_id" class="form-label">Customer</label><br>
            <select class="customer-select form-select" aria-label="Default select example" id="customer_id">
                <option></option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-danger" id="customer_id-error"></small>
        </div>
        <div class="col-md-3 mb-3">
            <label for="status" class="form-label">Payment Status</label><br>
            <select class="form-select form-select-sm" id="status">
                <option value="" selected>Chose Payment Status</option>
                <option value="1">Lunas</option>
                <option value="0">Utang</option>
            </select>
            <small class="text-danger" id="status-error"></small>
        </div>
        <div class="col-md-3 mb-3">
            <label for="description" class="form-label">Description</label><br>
            <textarea class="form-control form-control-sm" id="description" rows="1"></textarea>
        </div>
        <div class="col-md-3  mb-3">
            <label for="" class="form-label">&nbsp
            </label><br>
            <button type="button" class="btn btn-sm btn-primary" id="btn-create">Create New Transaction</button>
        </div>
    </div>
    <hr>
    <div class="table-responsive" style="overflow: auto">
        <table id="table-list" class="table table-striped table-hover" width="100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Date</th>
                    <th>Transaction</th>
                    <th>Customer</th>
                    <th>Price</th>
                    <th>Selling Price</th>
                    <th>Profit</th>
                    <th>Last Balance</th>
                    <th>Payment Status</th>
                    <th>Description</th>
                    
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <!-- Modal Update -->
    <div class="modal fade" id="modalUpdate" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1"
        aria-labelledby="modalUpdateLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalUpdateLabel">Update Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="mb-3">
                            <label for="name-update" class="form-label">Name *</label>
                            <input type="hidden" class="form-control border" id="id-update">
                            <input type="text" class="form-control border" id="name-update">
                            <small class="text-danger" id="name-update-error"></small>
                        </div>
                        <div class="mb-3">
                            <label for="purchase_price-update" class="form-label">Purchase Price *</label>
                            <div class="input-group border">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">RP.</span>
                                </div>
                                <input type="text" class="form-control text-end format-number"
                                    id="purchase_price-update">
                            </div>
                            <small class="text-danger" id="purchase_price-update-error"></small>
                        </div>
                        <div class="mb-3">
                            <label for="selling_price-update" class="form-label">Selling Price *</label>
                            <div class="input-group border">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">RP.</span>
                                </div>
                                <input type="text" class="form-control text-end format-number"
                                    id="selling_price-update">
                            </div>
                            <small class="text-danger" id="selling_price-update-error"></small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="btn-update">Save</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function format(nominal) {
            return new Intl.NumberFormat('en-US').format(nominal);
        }
        $(document).ready(function() {
            // Select 2 Products
            $('.product-select').select2({
                placeholder: "Select a product",
                allowClear: true
            });

            // Select 2 Customers
            $('.customer-select').select2({
                placeholder: "Select a customer",
                allowClear: true
            });

            $('#product_id').change(function() {
                var purchase_price = $(this).children('option:selected').data('purchase_price');
                var selling_price = $(this).children('option:selected').data('selling_price');
                var profit = selling_price - purchase_price;
                purchase_price = format(purchase_price);
                selling_price = format(selling_price);
                profit = format(profit);
                $('#purchase_price').val(purchase_price);
                $('#selling_price').val(selling_price);
                $('#profit').val(profit);
            });

            // List Data
            var table = $('#table-list').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('transaction')); ?>",
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'transaction',
                        name: 'products.name'
                    },
                    {
                        data: 'customer',
                        name: 'customers.name'
                    },
                    {
                        data: 'purchase_price',
                        name: 'products.purchase_price'
                    },
                    {
                        data: 'selling_price',
                        name: 'products.selling_price'
                    },
                    {
                        data: 'profit',
                        name: 'profit'
                    },
                    {
                        data: 'balance',
                        name: 'balance'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    // {
                    //     data: 'action',
                    //     name: 'action',
                    //     orderable: false,
                    //     searchable: false
                    // }
                ],
                columnDefs: [{
                        targets: 4,
                        createdCell: function(td, cellData, rowData, row, col) {
                            $(td).addClass('text-end')
                        }
                    },
                    {
                        targets: 5,
                        createdCell: function(td, cellData, rowData, row, col) {
                            $(td).addClass('text-end')
                        }
                    },
                    {
                        targets: 6,
                        createdCell: function(td, cellData, rowData, row, col) {
                            $(td).addClass('text-end')
                        }
                    },
                    {
                        targets: 7,
                        createdCell: function(td, cellData, rowData, row, col) {
                            $(td).addClass('text-end')
                        }
                    }
                ],
                order: [
                    [1, 'desc']
                ],
                pageLength: 5,
                lengthMenu: [5, 10, 20, 50, 100, 200, 500]
            });

            // Modal Update
            var ModalUpdate = new bootstrap.Modal(document.getElementById('modalUpdate'), {
                keyboard: false
            });

            // Create Data
            $('#btn-create').click(function() {
                var product_id = $('#product_id').children('option:selected').val();
                var purchase_price = $('#purchase_price').val();
                var profit = $('#profit').val();
                var customer_id = $('#customer_id').children('option:selected').val();
                var status = $('#status').children('option:selected').val();
                var description = $('#description').val();
                var token = $("meta[name='csrf-token']").attr("content");

                if (product_id.length == 0) {
                    $('#product_id-error').text('The product field is requered');
                } else {
                    $('#product_id-error').text(null);
                }

                if (customer_id.length == 0) {
                    $('#customer_id-error').text('The customer field is requered');
                } else {
                    $('#customer_id-error').text(null);
                }

                if (status.length == 0) {
                    $('#status-error').text('The payment status field is requered');
                } else {
                    $('#status-error').text(null);
                }

                if (product_id.length != 0 && customer_id.length != 0 && status.length != 0) {
                    $('#btn-create').prop('disabled', true);
                    $('#btn-create').text('Loading ...');

                    $.ajax({
                        url: "<?php echo e(route('transaction.store')); ?>",
                        type: "POST",
                        dataType: "JSON",
                        data: {
                            product_id,
                            customer_id,
                            profit: profit.replace(',', ''),
                            status,
                            description,
                            purchase_price: purchase_price.replace(',', ''),
                            '_token': token
                        },
                        success: function(res) {
                            table.ajax.reload();
                            toastr.success(res.message);

                            $('input').val(null);
                            $('#purchase_price').val(0);
                            $('#selling_price').val(0);
                            $('#profit').val(0);
                            $('#description').val(null);
                            $('option:selected', '#product_id').remove();
                            $('option:selected', '#customer_id').remove();
                            $('option:selected', '#status').remove();
                            $('#btn-create').prop('disabled', false);
                            $('#btn-create').text('Create New Transaction');
                        },
                        error: function(res) {
                            Swal.fire({
                                icon: 'error',
                                type: 'error',
                                title: 'Opps...',
                                text: res.responseJSON.message,
                            });

                            $('#btn-create').prop('disabled', false);
                            $('#btn-create').text('Create New Transaction');
                        }
                    })
                }
            });

            // Show Data
            // $('body').on('click', '#show-modal-update', function() {
            //     $('small').text(null);
            //     var id = $(this).data('id');
            //     var url = "<?php echo e(route('product.show', ':id')); ?>";
            //     url = url.replace(':id', id);
            //     $.get(url, function(data) {
            //         ModalUpdate.show();
            //         $('#id-update').val(data.data.id);
            //         $('#name-update').val(data.data.name);
            //         $('#purchase_price-update').val(data.data.purchase_price);
            //         $('#selling_price-update').val(data.data.selling_price);
            //     });
            // });

            // Update Data
            // $('#btn-update').click(function() {
            //     var id = $('#id-update').val();
            //     var name = $('#name-update').val();
            //     var purchase_price = $('#purchase_price-update').val();
            //     var selling_price = $('#selling_price-update').val();
            //     var token = $("meta[name='csrf-token']").attr("content");

            //     if (name.length == 0) {
            //         $('#name-update-error').text('The name field is requered');
            //     } else {
            //         $('#name-update-error').text(null);
            //     }

            //     if (purchase_price.length == 0) {
            //         $('#purchase_price-update-error').text('The purchase price field is requered');
            //     } else {
            //         $('#purchase_price-update-error').text(null);
            //     }

            //     if (selling_price.length == 0) {
            //         $('#selling_price-update-error').text('The selling price field is requered');
            //     } else {
            //         $('#selling_price-update-error').text(null);
            //     }

            //     if (name.length != 0 && purchase_price.length != 0 && selling_price.length != 0) {
            //         $('#btn-update').prop('disabled', true);
            //         $('#btn-update').text('Loading ...');
            //         var url = "<?php echo e(route('product.update', ':id')); ?>";
            //         url = url.replace(':id', id);

            //         $.ajax({
            //             url: url,
            //             type: "POST",
            //             dataType: "JSON",
            //             data: {
            //                 name,
            //                 purchase_price: purchase_price.replace(',', ''),
            //                 selling_price: selling_price.replace(',', ''),
            //                 '_token': token
            //             },
            //             success: function(res) {
            //                 table.ajax.reload();
            //                 $(".modal-backdrop.in").hide();
            //                 $('body').removeClass('modal-open');
            //                 $('.modal-backdrop').remove();
            //                 ModalUpdate.hide();
            //                 toastr.success(res.message);

            //                 $('#btn-update').prop('disabled', false);
            //                 $('#btn-update').text('Save');
            //             },
            //             error: function(res) {
            //                 Swal.fire({
            //                     icon: 'error',
            //                     type: 'error',
            //                     title: 'Opps...',
            //                     text: res.responseJSON.message,
            //                 });

            //                 $('#btn-update').prop('disabled', false);
            //                 $('#btn-update').text('Save');
            //             }
            //         })
            //     }
            // });

            // Delete Data
            // $('body').on('click', '#btn-delete', function() {
            //     Swal.fire({
            //         icon: 'info',
            //         type: 'info',
            //         title: 'Info',
            //         text: 'Are you sure to delele this data?',
            //         showCancelButton: true,
            //         showConfirmButton: true,
            //     }).then((res) => {
            //         if (res) {
            //             var id = $(this).data('id');
            //             var url = "<?php echo e(route('product.delete', ':id')); ?>";
            //             var token = $('meta[name="csrf-token"]').attr('content');
            //             url = url.replace(':id', id);
            //             $.ajax({
            //                 url: url,
            //                 type: "POST",
            //                 data: {
            //                     '_token': token
            //                 },
            //                 success: function(res) {
            //                     table.ajax.reload();
            //                     toastr.success(res.message);
            //                 },
            //                 error: function(res) {
            //                     Swal.fire({
            //                         icon: 'error',
            //                         type: 'error',
            //                         title: 'Opps...',
            //                         text: res.responseJSON.message,
            //                     });
            //                 },
            //             });

            //         }
            //     });
            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zikrillah\My Project\keuangan-pribadi\resources\views/transaction/list.blade.php ENDPATH**/ ?>